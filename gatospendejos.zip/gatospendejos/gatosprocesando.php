<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $direccion = $_POST["direccion"];
    $telefono = $_POST["telefono"];
    $edad = $_POST["edad"];
    $sexo = $_POST["sexo"];
    $ciudad = $_POST["ciudad"];

    
    if (empty($nombre) || empty($correo) || empty($direccion) || empty($telefono) || empty($edad) || empty($sexo) || empty($ciudad)) {
        echo "Todos los campos son obligatorios.";
    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        echo "Ingresa un correo electrónico válido.";
    } elseif (strlen($direccion) > 100) {
        echo "La dirección no puede tener más de 100 caracteres.";
    } elseif (!is_numeric($telefono)) {
        echo "El teléfono debe ser numérico.";
    } elseif (!is_numeric($edad) || $edad > 150) {
        echo "La edad debe ser un valor numérico y no mayor a 150.";
    } else {
        if ($edad >= 18) {
            echo "Registro correcto. ¡Bienvenido!";
        } else {
            echo "No puedes registrarte por ser menor de edad.";
        }

      
        echo '<p class="chiste">¡Registro exitoso! Felicidades, ¡te convertiste en un orgulloso miembro de los gatos pendejos!</p>';

  
        $gatos = ['gatopendejo1.jpeg', 'gatopendejo2.jpeg']; 

        $imagenAleatoria = $gatos[array_rand($gatos)]; 

        // Mostrar la imagen aleatoria de gato
        echo '<br><img src="' . $imagenAleatoria . '" alt="Gato Aleatorio">';
    }
}
?>