<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Registro</title>
    <link rel="stylesheet" type="text/css" href="gatospendejos.css">
</head>
<body>
    <div class="formulario">
        <h2>Formulario de Registro</h2>
        <form action="gatosprocesando.php" method="post">
            <input type="text" name="nombre" placeholder="Nombre">
            <input type="text" name="correo" placeholder="Correo">
            <input type="text" name="direccion" placeholder="Dirección">
            <input type="number" name="telefono" placeholder="Teléfono">
            <input type="number" name="edad" placeholder="Edad">
            <select name="sexo">
                <option value="masculino">Masculino</option>
                <option value="femenino">Femenino</option>
            </select>
            
            <?php
                $municipios = [
                    "Medellín", "Bogotá", "Cali", "Barranquilla", "Cartagena", 
                    "Bucaramanga", "Pereira", "Manizales", "Santa Marta", "Villavicencio",
                   
                    "Envigado", "Itagüí", "Sabaneta", "Rionegro", "Bello",
                  
                ];

                shuffle($municipios);

                echo '<select name="ciudad">';
                for ($i = 0; $i < 10; $i++) {
                    echo '<option value="' . $municipios[$i] . '">' . $municipios[$i] . '</option>';
                }
                echo '</select>';
            ?>

            <input type="submit" name="registrar" value="Registrar">
        </form>
        
        <?php
           
            echo '<p class="chiste">Por favor espera, estamos buscando a un gato pendejo para validar tus datos...</p>';
        ?>
        
    </div>
</body>
</html>