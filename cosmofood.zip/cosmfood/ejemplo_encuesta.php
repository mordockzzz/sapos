<!DOCTYPE html>
<html>
<head>
  <title>Ejemplo de Encuesta - Colegio Cosmo School</title>
  <link rel="stylesheet" href="styles_ejemplo_encuesta.css">
</head>
<body>
  <header class="header-ejemplo-encuesta">
    <h1>Ejemplo de Encuesta - Colegio Cosmo School</h1>
    <nav>
      <ul>
        <li><a href="index.html">Inicio</a></li>
        <li><a href="menu.html">Menú de Comidas</a></li>
        <li><a href="encuesta.php">Encuesta</a></li>
      </ul>
    </nav>
  </header>
  
  <main>
    <section>
      <h2>Ejemplo de Encuesta</h2>
      <p>¡Gracias por participar en nuestra encuesta! Actualmente estamos trabajando en la funcionalidad completa de la encuesta. Mientras tanto, te presentamos una encuesta de ejemplo:</p>
      <form>
        <label for="comida1"><input type="radio" id="comida1" name="comida" value="Ensalada de Pollo">Ensalada de Pollo</label><br>
        <label for="comida2"><input type="radio" id="comida2" name="comida" value="Tacos de Pescado">Tacos de Pescado</label><br>
        <label for="comida3"><input type="radio" id="comida3" name="comida" value="Batido de Frutas">Batido de Frutas</label><br>
        <input type="submit" value="Enviar">
      </form>
    </section>
  </main>

  <footer class="footer-ejemplo-encuesta">
    <p>Derechos de autor © Colegio Cosmo School</p>
  </footer>
</body>
</html>
