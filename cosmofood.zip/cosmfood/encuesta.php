<!DOCTYPE html>
<html>
<head>
  <title>Encuesta - Colegio Cosmo School</title>
  <link rel="stylesheet" href="styles_encuesta.css">
</head>
<body>
  <header class="header-encuesta">
    <h1>Encuesta - Colegio Cosmo School</h1>
    <nav>
      <ul>
        <li><a href="index.html">Inicio</a></li>
        <li><a href="menu.html">Menú de Comidas</a></li>
        <li><a href="encuesta.php">Encuesta</a></li>
      </ul>
    </nav>
  </header>
  
  <main>
    <?php
    // Verificar si el formulario se ha enviado
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      // Procesar el formulario y redirigir a la página de ejemplo
      header("Location: ejemplo_encuesta.php");
      exit;
    } else {
      // Mostrar el formulario de encuesta
    ?>
    <section>
      <h2>Añadir Comida</h2>
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <label for="comida">Nombre de la comida:</label>
        <input type="text" id="comida" name="comida" required>
        
        <label for="categoria">Categoría:</label>
        <select id="categoria" name="categoria" required>
          <option value="desayuno">Desayuno</option>
          <option value="mediamañana">Mediamañana</option>
          <option value="almuerzo">Almuerzo</option>
        </select>

        <label for="subcategoria">Subcategoría:</label>
        <input type="text" id="subcategoria" name="subcategoria" required>

        <input type="submit" value="Añadir Comida">
      </form>
    </section>
    <?php
    }
    ?>
    
      <section>
      <h2>Comidas más votadas</h2>
      <p>Aquí se mostrará la comida más votada en cada categoría y subcategoría.</p>
      <p>Todavía no se ha añadido ninguna comida. ¡Vota por tus opciones favoritas!</p>
    </section>
 
  </main>

  <footer class="footer-encuesta">
    <p>Derechos de autor © Colegio Cosmo School</p>
  </footer>
</body>
</html>


// para abrir pon esto http://localhost/cosmfood/encuesta.php