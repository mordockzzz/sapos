<?php
//Todas las conexiones entre php y las bases de datos requieren de los siguientes valores:

//1. Del servidor: Localhost
//2.Necesita usuario de la base de datos: root
//3.Contraseña de la base de datos: ''
//4.Nombre de la base de datos que se va a utilizar: matriculas

$servidor="localhost";
$usuario="root";
$clave="";
$basedatos="matriculas";//El nombre debe ser el mismo que esta en MySQ

//crear la conexion de datos
$conexion= new mysqli($servidor,$usuario,$clave,$basedatos);//ya esta ok la conexion de datos

// comprobar si existe algun error a la hora de conectarnos a la base de datos

if ($conexion->connect_errno)
{
    echo "nuestra conexion presenta fallas";
    exit();
}
?>