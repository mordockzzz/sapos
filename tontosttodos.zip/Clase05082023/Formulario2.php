<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario con el metodo POST</title>
</head>
<body>
    <h2>Inscripcion</h2>
    <form action="Formulario2.php" Method="post">
        <label for="">Nombre del cliente:</label><br>
        <input type="text" name="nombre" id="" placeholder="Nombres completos">
        <br><br>
        <label for="">Apellido del cliente:</label><br>
        <input type="text" name="apellido" id="" placeholder="Apellidos"><br><br>
        <label for="">Telefono:</label><br>
        <input type="Number" name="telefono" id="" placeholder="Numero de contacto"><br><br>
        <label for="">Correo electronico:</label><br>
        <input type="text" name="correo" id="" placeholder="ejemplo@gmail.com"><br><br>
        <label for="">Fecha de expedicion:</label><br>
        <input type="date" name="fecha" id=""><br><br>
        <button type="submit" name="guardar">Guardar los datos</button>
    </form>
    <?php
    if(isset($_POST['guardar']))
    {
    //1.Incluir el archivo de conexion para poder acceder a la variable conexion
    include('conexion.php');
    //2.Crear las variables que almacenan los datos del formulario
    $nombrecliente=$_POST['nombre'];
    $apellidocliente=$_POST['apellido'];
    $telefono=$_POST['telefono'];
    $correo=$_POST['correo'];
    $fecha=$_POST['fecha'];

    //3.Crear consulta en la base de datos
    //mysqli_query(conexion,consulta)
    mysqli_query($conexion,"INSERT INTO clientes (nombre,apellido,telefono,correo,fecha) values('$nombrecliente','$apellidocliente','$telefono','$correo','$fecha')");

    echo "Datos guardados correctamente";
    }
    
    
    ?>

</body>
</html>