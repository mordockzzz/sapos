<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularios HTML</title>
</head>
<body>
    <h2>Formularios HTML y PHP</h2>
    <p>
        1.Metodo GET: Los datos enviados por medio de un formulario tipo GET son visibles para el usuario en la URL de la pagina actual.
    </p>
    <form action="Formularios.php" metodo="GET">
        <!--en action siempre va el nombre del doc que procesa la informacion-->
        <Label>Ingrese su nombre:</Label><br>
        <input type="text" name="nombre" id="" 
        placeholder="Nombres">
        <br> <br>
        <Label>Ingrese sus apellidos:</Label><br>
        <input type="text" name="apellido" 
        placeholder="Apellidos">
        <br> <br>
        <Label>Ingrese su correo electronico:</Label><br>
        <input type="email" name="correo" 
        placeholder="ejemplo@gmail.com">
        <br> <br>
        <Label>Ingrese su numero de contacto:</Label><br>
        <input type="number" name="numero" id="" 
        placeholder="Telefono"><br><br>
        <input type="submit" value="Enviar datos" name="Guardar">
    </form>
    
    <?php
    //1.Validar que le den click al boton
    //Traer un elemento de HTML en PHP se hace con una variable global.
    //En este caso depende del metodo en el que definimos el formulario sea GET o POST
    //$_GET['name']; --- $_POST['name'];
    // y hay una funcion de php que valida que un elemnento (etiqueta) ha sido seleccionado: isset
    if(isset($_GET['Guardar']))
    {
        //En variables vamos a almacenar la informacion del formulario;
        $nombre=$_GET['nombre'];
        $apellido=$_GET['apellido'];
        $email=$_GET['correo'];
        $telefono=$_GET['numero'];
        echo "<p> El nombre ingresado es: ".$nombre."</p>";
        echo "<p> El apellido ingresado es: ".$apellido."</p>";
        echo "<p> El email ingresado es: ".$email."</p>";
        echo "<p> El telefono ingresado es: ".$telefono."</p>";
    }
    
    ?>

<p>
    2.Metodo post: los datos enviados por medio de un formulario tipo POST no sonvisibles para el usuario,por lo regular la mayoria de formularios son de este
</p>

<form action="Formularios.php" method="POST">
    <label for="">Ingrese su fecha de nac</label>
    <input type="date" name="fecha" id="">
    <br><br>
    <label for="">Ingrese su edad</label>
    <input type="number" name="edad" id="" placeholder="Edad">
    <br><br>
    <label for="">Ingrese la dirección</label><br>
    <input type="text" name="dirección" id="" placeholder="dirección">
    <br><br>
    <input type="submit" name= "Enviar" value="Enviar Datos">
</form>
<?php

    if(isset($_POST['Enviar']))
    {
        $fecha=$_POST['fecha'];
        $edad=$_POST['edad'];
        $direccion=$_POST['dirección'];
        
        echo "<p> Su fecha de nacimiento es: ".$fecha;
        echo "<br>";
        echo "<p> Su edad es: ".$edad;
        echo "<br>";
        echo "<p> Su direccion es: ".$direccion;
        echo "<br>";
    }
    
    ?>
</body>

</html>

